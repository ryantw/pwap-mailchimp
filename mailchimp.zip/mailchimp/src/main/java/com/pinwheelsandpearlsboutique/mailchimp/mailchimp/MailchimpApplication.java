package com.pinwheelsandpearlsboutique.mailchimp.mailchimp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MailchimpApplication {

	public static void main(String[] args) {
		SpringApplication.run(MailchimpApplication.class, args);
	}

}
